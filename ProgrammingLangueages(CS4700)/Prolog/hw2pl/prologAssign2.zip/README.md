## Synopsis

For every unchecked version it is just the normal name of the action. The checked versions have checked_ before the action. For example:

 * unchecked look: look(plaza).
 * checked look: checked_look(plaza).

 * unchecked take: take(clean_clothes).
 * checked take: checked_take(clean_clothes).
